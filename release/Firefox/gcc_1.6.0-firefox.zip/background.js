console.log('Initializing Background script in Firefox')
